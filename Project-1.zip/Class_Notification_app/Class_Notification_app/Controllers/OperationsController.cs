﻿using Class_Notification_app.Data;
using Class_Notification_app.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using Microsoft.Data.SqlClient;

namespace Class_Notification_app.Controllers
{
    public class OperationsController : Controller
    {
        private readonly ApplicationContext context;

        public OperationsController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult DeletePost(int id)
        {
            if (User.Identity.IsAuthenticated && HttpContext.Session.GetString("User_Type") == "Instructor")
            {
                var post = context.Instructor_Post.SingleOrDefault(p => p.Id == id);
                context.Instructor_Post.Remove(post);
                context.SaveChanges();
                return RedirectToAction("Instructor_Post", "User");
            }

            return RedirectToAction("Login", "User");
        }

        public IActionResult EditPost(int id)
        {
            if (User.Identity.IsAuthenticated && HttpContext.Session.GetString("User_Type") == "Instructor")
            {
                var post = context.Instructor_Post.SingleOrDefault(p => p.Id == id);
                var result = new Instructor_Post()
                {
                    Id=post.Id,
                    Title = post.Title,
                    Description = post.Description,
                };
                return View(result);
            }

            return RedirectToAction("Login", "User");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditPost(Instructor_Post model) // When Instructor clicks submit button the following code gets executed;
        {

            if (User.Identity.IsAuthenticated && HttpContext.Session.GetString("User_Type") == "Instructor")
            {
                if (ModelState.IsValid)
                {
                    var p = new Instructor_Post
                    {
                        Id = model.Id,
                        Title = model.Title,
                        Description = model.Description,
                        Author = HttpContext.Session.GetString("Author")

                    };
                    context.Instructor_Post.Update(p);
                    context.SaveChanges();
                    return RedirectToAction("Landing_Page","User");
                }
                else
                {
                    return View();
                }
            }
            
                return RedirectToAction("Login", "User");
            }
        }
  }

